1. open terminal or console to the target folder : cd Final_Project
2. install the server: npm install -g http-server
3. If there were some errors, run: sudo npm install -g http-server  and then input the password of computer
4. run: http-server(for mac os)
   run: npx http-server(for windows)
5. input: 127.0.0.1:8080 in browser

